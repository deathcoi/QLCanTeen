package constant;

public class HttpConstant {
	public static final String HTTPREQUESTPOST = "post";
	public static final String HTTPREQUESTGET = "get";
	public static final String HTTPREQUESTPUT = "put";
	public static final String HTTPREQUESTDELETE = "delete";
}
