package com.APISpring.service;

import com.APISpring.entities.LoaiMonAn;

public interface ILoaiMonAnService {
	LoaiMonAn save(LoaiMonAn loaiMonAn);
	LoaiMonAn update(LoaiMonAn loaiMonAn);
	void delete(LoaiMonAn loaiMonAn);
}
