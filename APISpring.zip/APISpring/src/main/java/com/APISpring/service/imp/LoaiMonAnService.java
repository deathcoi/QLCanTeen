package com.APISpring.service.imp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.APISpring.dao.ILoaiMonAnDAO;
import com.APISpring.entities.LoaiMonAn;
import com.APISpring.service.ILoaiMonAnService;

@Service
public class LoaiMonAnService implements ILoaiMonAnService{

	@Autowired
	ILoaiMonAnDAO loaiMonAn;
	
	@Override
	public LoaiMonAn save(LoaiMonAn l) {
		try {
			loaiMonAn.saveLoaiMonAn(l);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return l;
	}

	@Override
	public LoaiMonAn update(LoaiMonAn l) {
		try {
			loaiMonAn.updateLoaiMonAn(l);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return l;
	}

	@Override
	public void delete(LoaiMonAn l) {
		try {
			loaiMonAn.deleteLoaiMonAn(l);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
