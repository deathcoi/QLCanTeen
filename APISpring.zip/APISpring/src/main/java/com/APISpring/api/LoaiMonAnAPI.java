package com.APISpring.api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.APISpring.entities.LoaiMonAn;
import com.APISpring.service.ILoaiMonAnService;

@RestController(value = "/api/loaimonan")
public class LoaiMonAnAPI {
	
	@Autowired
	ILoaiMonAnService loaiMonAnService;
	
	@PostMapping("api/loaimonan")
	public LoaiMonAn createLoaiMonAn(@RequestBody LoaiMonAn loaiMonAn) {
		loaiMonAnService.save(loaiMonAn);
		return loaiMonAn;
	}
}
