package com.APISpring.dao;

public interface IGeneric<T> {
	@SuppressWarnings("hiding")
	<T> T save(T saver);
	@SuppressWarnings("hiding")
	<T> T update(T updater);
	<T> void Delete(T deleter);
}
