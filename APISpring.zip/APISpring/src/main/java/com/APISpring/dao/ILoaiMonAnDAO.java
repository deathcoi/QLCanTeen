package com.APISpring.dao;

import com.APISpring.entities.LoaiMonAn;

public interface ILoaiMonAnDAO extends IGeneric<LoaiMonAn>{
	LoaiMonAn saveLoaiMonAn(LoaiMonAn l);
	LoaiMonAn updateLoaiMonAn(LoaiMonAn l);
	void deleteLoaiMonAn(LoaiMonAn l);
}
